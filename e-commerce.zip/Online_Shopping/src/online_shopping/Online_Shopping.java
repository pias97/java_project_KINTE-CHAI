/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package online_shopping;

/**
 *
 * @author USer
 */


class global{
    public static int total=0;
    public static int quantity=0;
    
    //mobile
    public static int mob1=0;
    public static int mob2= 0;
    public static int mob3= 0;
    public static int mob4 = 0;
    public static int mob5= 0 ;
    
    //TV
    public static int tv1=0;
    public static int tv2=0;
    public static int tv3=0;
    public static int tv4=0;
    
    //laptop
    public static int laptop1=0;
    public static int laptop2=0;
    public static int laptop3=0;
    public static int laptop4=0;
    public static int laptop5=0;
    
    //headphone
    public static int headphone1=0;
    public static int headphone2=0;
    public static int headphone3=0;
    public static int headphone4=0;
    public static int headphone5=0;
    
    //computer parts
    public static int comp1=0;
    public static int comp2=0;
    public static int comp3=0;
    public static int comp4=0;
    public static int comp5=0;
    
    //cosmetics
    public static int cos1=0;
    public static int cos2=0;
    public static int cos3=0;
    public static int cos4=0;
    public static int cos5=0;
    
    //men's
    public static int men1=0;
    public static int men2=0;
    public static int men3=0;
    public static int men4=0;
    public static int men5=0;
    
    //woman's
    public static int woman1=0;
    public static int woman2=0;
    public static int woman3=0;
    public static int woman4=0;
    public static int woman5=0;
    
    //sports
    public static int sp1=0;
    public static int sp2=0;
    public static int sp3=0;
    public static int sp4=0;
    public static int sp5=0;
    
    //toys
    public static int toy1=0;
    public static int toy2=0;
    public static int toy3=0;
    public static int toy4=0;
    public static int toy5=0;
    
}



public class Online_Shopping {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        System.out.println("Hello");
    }
    
}
